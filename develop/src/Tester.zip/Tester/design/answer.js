document.addEventListener('DOMContentLoaded', () => {
    // Optional: Go back to previous page
    const backBtn = document.getElementById('backBtn');
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.history.back();
        });
    }
    // You can add more JS here if you want to load dynamic content!
});